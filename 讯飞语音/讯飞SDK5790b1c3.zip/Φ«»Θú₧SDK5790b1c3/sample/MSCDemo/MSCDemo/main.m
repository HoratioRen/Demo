// 
//  main.m
//  MSCDemo
//
//  Created by iflytek on 13-6-5.
//  Copyright (c) 2013年 iflytek. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MSCAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([MSCAppDelegate class]));
    }
}
	